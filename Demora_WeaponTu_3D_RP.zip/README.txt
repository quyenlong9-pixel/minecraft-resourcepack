DEMORA LEGENDARY WEAPONS 7.0 - WEAPONTU 3D RESOURCE PACK

The supplied Demora 7.0 plugin already assigns CustomModelData to its items.
This pack maps those material/CMD combinations to 3D item models and includes
the corresponding WeaponTu/Civilization model and texture assets.

Install:
1. Put this ZIP in the Minecraft client's resourcepacks folder and enable it.
2. To distribute to all players, host this ZIP at a direct HTTPS URL and set
   resource-pack and resource-pack-sha1 in server.properties.
3. Keep the supplied DemoraLegendaryWeapons 7.0 plugin installed.

Plugin:
- The plugin JAR is not modified. Its abilities, damage, cooldowns and item data
  remain unchanged; the existing CMD values are what select the models.

Compatibility:
- The pack contains both legacy CustomModelData overrides and modern item
  definitions using minecraft:custom_model_data range dispatch.
- pack.mcmeta uses pack_format 34 as a conservative legacy baseline. The exact
  client/resource-pack format for a server labelled Paper 1.26.3 must be checked
  in-game; if the client warns/rejects the pack, the metadata may need updating.
- Several model choices are visual approximations where WeaponTu does not contain
  an exact counterpart (e.g. awakened katana uses the katana model; freezing
  chakram uses a frost-themed sword model; sculk crossbow uses a crossbow model).
- No custom model was present in WeaponTu for every single Demora item. Items
  without a matching entry retain their vanilla appearance.

This is a client-side resource pack; it does not convert the Fabric mod into a
server plugin and does not require installing WeaponTu on the server.
